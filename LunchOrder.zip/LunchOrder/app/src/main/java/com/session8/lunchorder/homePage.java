package com.session8.lunchorder;


import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class homePage extends AppCompatActivity {
    private Button lunchButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_page);

        lunchButton = (Button)findViewById(R.id.lunchButton);
        lunchButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openorderPage();
            }
        });

    }

    // open order page to bring to new activity page. when this is clicked it will
    // create the order using the different classes
    // when order page is opened it should display the string from lunchcombo.java


    public void openorderPage(){
        Intent intent = new Intent(this, orderPage.class);
  //     startActivity(intent);
    }


}