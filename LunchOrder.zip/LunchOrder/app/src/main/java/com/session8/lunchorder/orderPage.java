package com.session8.lunchorder;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class orderPage extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_order_page);
    }
}